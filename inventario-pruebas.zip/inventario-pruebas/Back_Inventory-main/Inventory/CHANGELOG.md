## [1.7.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/60) (2021-05-19)
**Added**
- [VALLESOFT-286] Added documentation about returning makefile.

## [1.6.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/57) (2021-05-15)
**Added**
- [VALLESOFT-59] Added documentation about article makefile.

## [1.5.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/55) (2021-05-14)
**Added**
- [VALLESOFT-238] Added documentation about article update.

## [1.4.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/40) (2021-04-16)
**Added**
- [VALLESOFT-204] Added documentation about borrowing and article type

## [1.3.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/34) (2021-04-13)
**Added**
- [VALLESOFT-204] Added documentation to list, approve and reject returning. 

## [1.2.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/33) (2021-04-12)
**Added**
- [VALLESOFT-106] Added documentation to create returning.

## [1.1.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/30) (2021-04-11)
**Modified**
- [VALLESOFT-101-107] Added documentation filter articles by warehouse_id, branch and article type id.

## [1.0.0](https://github.com/TEAMVALLESOFT/Back_Inventory/pull/29) (2021-04-10)
**Added**
- [VALLESOFT-187] Added documentation for users, articles and warehouses.
